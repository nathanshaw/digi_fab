                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1243367
USB Cable Holder (6 Cables) for Pegboard by futur3gentleman is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

<h4>Manhattan Pegboard Collection for 3D Printers</h4>
Get organized! The Manhattan Pegboard Collection for 3D Printers is a group of modern, customizable parts that allow you to generate bins, mounts, holders and even shelves for nearly every object that you may want to have neatly hung on a pegboard. 

As a NYC native, I never had ‘extra space’ in my home. So when I purchased an <a href="http://amzn.to/1RoE4en">Ultimaker 2 3D Printer</a> ten months ago, I knew that I wanted to use it to improve my life. By mounting <a href="http://amzn.to/1TYKq29"> modular pegboards</a> strategically throughout my home, I have been able to create custom mounts for all of the little things in life and place them exactly where they need to be. I now manage to keep ‘everything in its place’ because everything has a place to go!

<h6>Parts in the Collection</h6>
• <a href="https://www.thingiverse.com/thing:1268879">Customizable Holder (2-Peg) for Pegboards</a>
• <a href="https://www.thingiverse.com/thing:1268880">Customizable Holder (4-Peg) for Pegboards</a>
• <a href="https://www.thingiverse.com/thing:1268882">Customizable Rounded Holder for Pegboards</a>
• <a href="https://www.thingiverse.com/thing:1268816">Pedestal Shelf for Pegboards</a>
• <a href="https://www.thingiverse.com/thing:1243367">USB Cable Holder (6 Cables) for Pegboard</a>

You can view all of the custom parts that I have designed for my home <a href="http://www.mattmanhattan.com/2016/01/16/the-manhattan-pegboard-collection-for-3d-printers/">here</a>, or you can start printing your own today!
<br>
<h4>USB Cable Holder (6 Cables) for Pegboard</h4>

This is a USB Cable Holder that will hold up to six USB cables. Have more cables? Print more USB Cable Holders!

<br>
<h5>Bitcoin Tip!</h5>
If you feel that this item has improved or simplified your life, please consider a small tip:

<a href="http://bit.ly/3Dpegboards">1BzAqfotNncsVCbsonwVN3NZDagJzsk6zM</a>

# Print Settings

Printer Brand: Ultimaker
Printer: Ultimaker 2
Rafts: No
Supports: Yes

Notes: 
Depending on a variety of factors your print results may vary! Some of my prints slide into the pegboard peg holes without issue, and sometimes it requires a bit of extra force. If you find that the pegs are not printing well, make sure your support structures are adequately supporting most or all of the entire peg (depending on your settings). 
<br><br>
I print my pegboard pieces using an <a href="http://amzn.to/1RoE4en">Ultimaker 2</a> with an <a href="http://printedsolid.com/collections/accessories-and-upgrades/products/olsson-block-for-ultimaker-2">Olsson Block</a> running a <a href="http://gr5.org/store/index.php/um/1mm-nozzle.html">1mm nozzle</a>. The prints in the included photos were printed using <a href="http://amzn.to/1RIF2CK">Verbatim PLA in White</a>. With this setup I can print durable pegboard parts at a 0.5mm layer height with reasonable speed.