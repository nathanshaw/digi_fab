                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1927038
Reed for Saxophone/Clarinet customizer by alex_belov is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This customizer creates a model of saxophone/clarinet reed (similar in construction).
The model is parameterized with many parameters that target full music instruments line of mouthpieces. The default parameters are set for ABS reed for Alto Saxophone mouthpiece. I've checked how it sounds with the model http://www.thingiverse.com/thing:14495
... and it works well. I have not checked yet how it sounds with alto sax, but I'll update the summary when I get access to it in the nearest future.
The parameterized model of the customizer can be described as a variable radius cone that is intersected with the cylinder of reed blank.
The reed blank is parameterized by:
Reed Overall Length;
Reed Cylinder Radius - defines curvature of the reed place in contact with ligature;
Reed Back Thickness - defines maximum thickness of ligature part of the reed;
Reed Back Width - defines ligature reed end desireable width;

The tip is parameterized by:
Reed Tip Crosscut Сurvature - this provides non-flat profile of the tip and work as a base curvature for local profile changes below;
Reed Tip Crosscut Increment Element N - define increment of the Reed Tip Crosscut Сurvature parameter, so that positive values further decrease curvature, while negative values increase curvature, and parameter is in the same units; For example if Reed Tip Crosscut Сurvature is 200mm and Reed Tip Crosscut Increment Element 1 is (-1)mm then local curvature at 1 is 199mm; Elements are numbered from tip end to the middle of the reed;
Reed Tip Cut Angle - defines the parameterized variable curvature cone axle inclination from tip end to the middle of the reed;
Reed Tip End Width - defines tip end width; Note that Reed Cylinder Radius and Reed Back Thickness influence what is the maximum Reed Tip End Width make sense, otherwise tip end exceeds rest part of the tip;
Reed Tip End Round - defines rounded form of the tip end - which part of Reed Overall Length is rounded with ellipse, or ellipse semiminor axis;
Reed Tip Initial Thickness - defines tip end thickness when Reed Tip Crosscut Increment Element 0 is 0mm, and the tip end point height to apply Reed Tip Cut Angle;

That is it. Happy experiments with this reed engine. ;)

12/01/2016 - added height to text, otherwise it is not etched
12/02/2016 - updated cone correction formula for neighbor elements
12/03/2016 - checked Alto V model in Remixes with my saxophone. See results in the particular model Summary.
12/04/2016 - checked Alto W model in Remixes with my saxophone. Reed own resonanse raised one semitone higher  than Reed V for second octave C2# best response.
12/31/2016 - minor error is fixed. Fix simplified source code a bit. No other changes.
12/31/2016 - new engine version http://www.thingiverse.com/thing:2006116 with more flexibility in specification of reed 3D model, simplified parameters perception, that should popularize work with the new engine. Also parameters for different instruments mounthpieces are more compartible in the new engine since they less depend on the modelled reed size parameters. There may be still some arguments to use this engine, since the elements form is specified with less params for the particular saxophone/clarinet.

PS: thanks to http://www.thingiverse.com/thing:817389 for the initial idea to create this customizer
PPS: Looks like I was able to fine tune Customizer aware scad structure and Customizer shows all parameters now, but since the 3D drawing is not informative just use OpenSCAD for proper viewing.