                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1807378
Folded Tabor Pipe by MangoCats is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

Work in progress, especially some of the customizer options, but the pipes are printable, playable, and more or less in tune.

A Tabor pipe is a tin whistle with only 3 holes (thus, playable with one hand).  Ordinary straight Tabor pipes are upwards of 270mm long, not really printable on my bed, but if you take the pipe and fold it....  A true Tabor has the 3rd hole on the bottom, a little SCAD work should enable you to add that option.

Ultimately, I want to be able to print two well tuned Tabors (in different keys) in mirror image and attach them to each other so they can be played simultaneously.

# Print Settings

Printer: FlashForge Dreamer
Rafts: No
Supports: No
Resolution: High (0.14mm)
Infill: Default (15% Hex)

Notes: 
Nothing special going on in the print process.  Overhangs are 45 degrees, except in the holes.

Print takes about 3 hours at 0.14mm layer height and 40mm/s print speed, 15% hex infill, 3 shells and 4 layers top and bottom.  A soprano D consumes about 5m of 1.75 filament with the walls set at 0.64mm thick.

The larger parts are having shrinkage problems in ABS - PLA seems to still be working well up to the width of the printer bed.  The "Cv1" low variant is much larger than the soprano D, it barely fits on the bed when turned diagonally and is showing a 16 hour print time, consuming 25 meters of PLA... I'm going to try to print that one next, after this hurricane passes.  Drying the filament (baking at 180F for 2 hours) and a bit of hairspray on the bed seem to be helping the PLA print stay stuck.

# Post-Printing

## Acetone vapor polishing

Only for ABS, it's not necessary, but can make a nicer finish.

There's a through hole near the end which I put there to facilitate "hanging" this part in a jar over heated acetone - it makes the surface much smoother, but the part will be smelly for a few days.

I heat about 3/4" of water to a boil in a pot, then pour about 1/4" of acetone (nail polish remover works) in the bottom of a glass jar, put the part on a wire hanger in the jar, put the jar in the pot (now heating to just under 100C), put a plate over the jar lid and wait for 10 minutes or so, then remove and let the part sit for a few hours to "firm up the skin" before touching it.  Oh, and the water is boiled on the stove, then carried outside (to sit on the grill) to make the hot acetone vapor.  I've been dumping the used acetone on a weed growing in the sidewalk, it doesn't seem to mind.

I've heard that "flame polishing" does a similar thing for PLA, but I've never tried it.

# How I Designed This

## References

First: http://www.ggwhistles.com/howto/ is a great guide for practical whistle making... when I get this completely figured out, I plan to mail him one as a thank-you.

OpenSCAD makes parametric design very accessible, and tuning a whistle like this is all about setting up the parameters.

I'm using an app called gStrings on my phone to read the pipes' tune.

Some notes on windway design around p. 29 here http://www.fomrhi.org/uploads/bulletins/Fomrhi-113.pdf

Not sure if I'm ready to engage with this crew yet: http://forums.chiffandfipple.com/viewforum.php?f=1

For a first design, I'm working on a 268mm D pipe, which should also play E, F# and G by opening the bottom 1, 2 and all 3 holes, respectively.

The main trick I have to accomplish is figuring out the "equivalent length" of pipe bends.  My first guess was to assign them their "centerline length" which resulted in a very flat tune (pipe too short).  So, I moved to assigning each 90 degree corner an equivalent length of the pipe diameter.  This gave me a 598Hz D (40 cents sharp), 672Hz E, 752Hz F#, and 798Hz G - all about 40 cents sharp.

For my next iteration, I tried "discounting" the final bend since it opens as a hole.  This moved all the finger holes back about 12mm (it was late, I didn't think about it before starting the print and going to bed) - and the tune with the holes "open" is quite similar to the longer pipe with the shorter body.  With all holes closed, the D is now about 40-50 cents flat.  So, if the overall length hits the middle of trials 1 and 2, D should be getting close, but the holes need to move about 6mm closer to the end. D 572, E 675, F# 760, G 800 before polishing, and just a tiny bit flatter after polishing.

I've printed a couple of Alto G pipes now, one with 6 holes (more a tin whistle than a Tabor) - the low note is still hard to hold, I haven't tried "rigging the fipple" yet - that's next.  Also, since the low note is the only one resonating completely through the lower bends, I revised that area to have a larger diameter curve, which does seem to help.

So far, I like the "tone" of ABS and thicker walls better than PLA with thin walls, but there are more variables at play than just the material type.  A big variable is hole roughness, if you get a good seal on the finger holes, PLA and ABS sound very similar.