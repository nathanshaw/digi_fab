                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1012353
Single Print Ocarina by 3E8 is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This beautiful item took a lot of experimentation (and a ton of ABS) to get right... but the final product produces a full octave and then some!  No gluing parts together or tuning - just print and play!  The latest 60 degree tone hole version goes from a gentle 311 Hz to a crisp 846 Hz.  Enjoy!  

Here's what the original sounded like (367 to 785 Hz): https://youtu.be/0IR7k_Dgxpk  
... and a baseball classic: https://youtu.be/EPKkUctNxvs

If you print this, please kindly click "I Made One" and share pictures and videos!  I love that stuff!

December 8th, 2015 update:  Here's a mid-sized 4-hole ocarina:

http://www.thingiverse.com/thing:1184228

February 2nd, 2016 update: added a V3 with new tone hole which functions a little better!

Sept 11th, 2016 update: modified the tone hole a touch so that you can blow more firmly at higher notes (all holes open) and it makes a good solid sound.  When all holes are covered, you'll need to blow more lightly.

Dec 21st, 2016 update: Fixed the mid-seam issue that some printers that use a layer height of .2mm or less may experience.

# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator
Rafts: No
Supports: No
Infill: 10% to 100%

Notes: 
No supports necessary, just print as is, where is. I used 10% infill for all of the ones I've ever printed, however you'd probably end up with the sharpest sound if you went 100% (and added acetone vapor treatment). Nonetheless, it plays right off the build plate.